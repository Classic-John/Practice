using AboutMiddleware.CustomaMiddleware;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

/*
app.Run(async (HttpContext context) =>  //.Run executes terminating/short-circuit middleware that doesn't forward the request to the next middleware
{ 
    //code  
});
*/

//remember, the middleware order matters => it determines the execution order

//middleware 1  
app.Use(async (HttpContext context, RequestDelegate next) =>  //.Use can be used for both terminating and continuing the middleware chaining
{
    await context.Response.WriteAsync("I like hot girls\n");
    await next(context);
});

//app.UseMiddleware < MyCustomMiddleware>();   // first way of calling custom middleware
app.UseCustomExtension();  //second way of calling a custom middleware (with dynamic methods)
app.UseHelloMiddleware(); //third way, from c#s preimplemented middleware class.

app.UseWhen(
    context => context.Request.Query.ContainsKey("username"), //if condition is true, it goes to the app lambda stuff
    app =>
    {
        app.Use(async (context, next) =>
        {
            await context.Response.WriteAsync("Hello from middleware branch");
            await next(context);
        });
    });

app.Run(async (HttpContext context) =>
{
    await context.Response.WriteAsync("Hello from middleware at main chain");
});

app.Run();


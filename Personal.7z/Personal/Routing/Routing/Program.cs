using Microsoft.AspNetCore.Http;
using Routing.CustomConstraints;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRouting(options =>
{
    options.ConstraintMap.Add("months", typeof(MonthsContraint));  //remember: put any adds in builder before .Build()
});
var app = builder.Build();


app.Use(async (context, next) =>
{
    Endpoint endpoint = context.GetEndpoint();
    if (endpoint != null)
    {
        await context.Response.WriteAsync($"Endpoint:{endpoint.DisplayName}\n");//it's null because it's before .UseRouting()
    }
    await next(context);
});

app.UseRouting(); //enables routing

app.Use(async (context, next) =>
{
    Endpoint endpoint = context.GetEndpoint(); // it's null because no endpoint had the chance to be selected
    if (endpoint != null)
    {
        await context.Response.WriteAsync($"Endpoint:{endpoint.DisplayName}\n");
    }
    await next(context);
});

//create endpoints
app.UseEndpoints(endpoints =>  //takes all endpoints you want to exist in the api
{
    //add endpoint
    endpoints.Map("files/{filename}.{extension}", async (context) =>             //{} in routes means that anything after the " / " is acceptable
    {
        string filename = Convert.ToString(context.Request.RouteValues["filename"]);
        string extension = Convert.ToString(context.Request.RouteValues["extension"]);
        await context.Response.WriteAsync($"You are in files -{filename}.{extension}\n");
    });
    endpoints.Map("employee/profile/{employee:alpha}", async (context) =>  //alpha means the string matches only with alphabets
    {
        string employee = Convert.ToString(context.Request.RouteValues["employee"]);
        await context.Response.WriteAsync($"In profile - {employee}\n");
    });
    endpoints.Map("products/details/{id=1}", async (context) =>     //[id] = [value] => default value (in case the user doesn't provide one)
    {
        int id = Convert.ToInt32(context.Request.RouteValues["id"]);
        await context.Response.WriteAsync($"Product's id: {id}");
    });
    endpoints.Map("products/{id:int:range(1,1000)?}", async (context) =>   //{id?} == optional parameter. range (min,max) 
    {
        if (context.Request.RouteValues.ContainsKey("id"))
        {
            int id = Convert.ToInt32(context.Request.RouteValues["id"]);
            await context.Response.WriteAsync($"Product's id: {id}\n");
        }
        else
        {
            await context.Response.WriteAsync("Product doesn't exist\n");
        }

    });

    endpoints.Map("daily-report/{report:datetime}", async (context) =>            //route constraints (basically the route parameter is forced to be of a certain data type_
    {
        DateTime reportDate = Convert.ToDateTime(context.Request.RouteValues["report"]);
        await context.Response.WriteAsync(reportDate.ToString());
    });

    endpoints.Map("cities/{cityId:guid}", async (context) =>   //this data type is a "globally unique identifier" (GUID). Cool data type, i think you can use around 5-6 types
    {
        Guid cityId = Guid.Parse(Convert.ToString(context.Request.RouteValues["cityId"]));
        await context.Response.WriteAsync($"The city's id: {cityId}");
    });

    //multiple constrains example. others:minValue, maxValue
    endpoints.Map("ports/{pId:int:length(2,10)}", async (context) =>   //odd behaviour, length(n,m) is the interval where id's aren't accepted for some reason.
    {
        int pId = Convert.ToInt32(context.Request.RouteValues["pId"]);
        await context.Response.WriteAsync(pId.ToString()+"i am here");
    });

    endpoints.Map("sales-report/{year:int:min(1900)}/{month:months}", async (context) =>  //month:regex(^(apr|jul|oct|jan)$) example for regex
    {
        int year = Convert.ToInt32(context.Request.RouteValues["year"]);
        int month= Convert.ToInt32(context.Request.RouteValues["month"]);
        await context.Response.WriteAsync($"sales date => year: {year}:{month}");
    });
    
    endpoints.Map("Map0", async (context) =>                   //.Map(... , ...) Can be used for both Get and Post( even from Postman) or any other request
    {
        await context.Response.WriteAsync("I am Map method\n");
    });
    endpoints.MapGet("map1", async (context) =>    //[endpoint's name] , [context]        //takes Get requests only
    {
        await context.Response.WriteAsync("First endpoint\n");
    });
    endpoints.MapPost("map2", async (context) =>                                            //takes Post requests only
    {
        await context.Response.WriteAsync("Second endpoint\n");
    });
    endpoints.Map("sales-report/2024/oct", async context =>       //this has the highest priority, then a/b/c > a/b > a/{b}:int > a/{b} > a/{**} (catch all parameters)
    {
        await context.Response.WriteAsync("You deserve an award");
    });
});

app.Run(async (context) =>
{
    context.Response.WriteAsync("This page does actually work\n");
});

app.Run();

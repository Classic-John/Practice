﻿using Asp.net_tests.CustomValidators;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace Asp.net_tests.Models
{
    public class Person: IValidatableObject
    {
        [Required(ErrorMessage = "{0} can't be empty or null")] //{0} prints the property itself (with the name you gave it)
        [Display(Name = "VIP Name")] //this will display instead of property's actual code name and will pop up when {0} is used
        [StringLength(maximumLength: 30, MinimumLength = 8, ErrorMessage = "{0}'s lenght not in range. Range accepted:[{2} , {1} ]")] //{0} is reserved for the property, the others are reserved for the model validation parameters
        [RegularExpression("^[A-Za-z .]*$", ErrorMessage ="{0} contains forbidden characters")] //remember, star in regular expresion=> more characters, not only one
        public string? Name { get; set; }

        [Required]
        [EmailAddress(ErrorMessage ="Email doesn't respect email conventions")] //just a model validation attribute existing doesn't make the field mandatory, only [Required] does it
        public string? Email { get; set; }

        [Phone(ErrorMessage ="{0} must have 10 digits")]
        [ValidateNever] //this exists aswell =))
        public string? Phone { get; set; }

        [Required(ErrorMessage ="{0} can't be empty")]
        public string? Password { get; set; }

        [Required(ErrorMessage = "{0} can't be empty")]
        [Compare("Password",ErrorMessage ="{0} and {1} must match")]
        [Display(Name="Confirm password")]
        public string? ConfirmPassword{get; set;}

        [Range(0,999.99,ErrorMessage ="Not in range. Range accepted:[{1},{2}]")]
        public double? Price { get; set; }
        [MinimumYearValidator(2010)]
        public DateTime? Date { get; set; }
        
        public DateTime? FromDate { get; set; }
        [DataRangeValidator("FromDate",ErrorMessage ="Condition must be true: {0} >= {1}")]
        [BindNever] //better for telling the IDE which property you don't want to bind with the action methods (security reasons)
        public DateTime?ToDate { get; set; }
        public int? Age { get; set; }

        public override string ToString()
        {
            return $"Name:{Name}\n Email:{Email}\n Phone:{Phone}\n Password:{Password}\n ConfirmPassword:{ConfirmPassword}\n Price:{Price}\n";
        }

        public IEnumerable<ValidationResult>Validate(ValidationContext validationContext) //this way of doing validations is not reusable (no reflexion or complex contructors usable for other models too)

        {
            if(!Date.HasValue && !Age.HasValue) //yield return allows you to return more times in a single method
            {
                yield return new ValidationResult("Date and Age not supplied", new []{nameof(Date)});  
            }
        }

        //you can add even a List (container) here and you can do collection binding , ex: Tags[0] = ... ; Tags[1] = ...

    }
}

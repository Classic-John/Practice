using Asp.net_tests.CustomModelBinders;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers( options =>
{
    options.ModelBinderProviders.Insert(0, new PersonBinderProvider()); //this allows you to type only Person [varName] as parameter for action methods (ypu don't need that long custom binding text again if you use this
});
//builder.Services.AddControllers().AddXmlSerializerFormatters;  //doesn't work for me
var app = builder.Build();

app.UseRouting();
app.MapControllers();
app.Run();

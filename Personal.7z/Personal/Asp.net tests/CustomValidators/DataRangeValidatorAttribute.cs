﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Asp.net_tests.CustomValidators
{
    public class DataRangeValidatorAttribute:ValidationAttribute
    {
        public string? OtherPropertyName { get; set; }
        public DataRangeValidatorAttribute(string otherPropertyName)
        {
            OtherPropertyName = otherPropertyName;
        }
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value != null)
            {
                //reflection helps using/invoking methods from dynamic objects
                DateTime toDate=Convert.ToDateTime(value);

                PropertyInfo? otherProperty=validationContext.ObjectType.GetProperty(OtherPropertyName);
                DateTime fromDate=Convert.ToDateTime(otherProperty.GetValue(validationContext.ObjectInstance));
                if(fromDate > toDate) 
                {
                    return new ValidationResult(ErrorMessage,new string[] {OtherPropertyName,validationContext.MemberName});
                }
                return ValidationResult.Success;
            }
            return null;
        }
    }
}

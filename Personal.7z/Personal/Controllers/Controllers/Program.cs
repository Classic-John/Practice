var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers(); //adds routing+ other stuff for full controller functionality by default
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.MapControllers(); //But you need to write .MapControllers()
app.Run();

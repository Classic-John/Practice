using Microsoft.Extensions.Primitives;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

/*app.Run(async (HttpContext context) =>
{
    context.Response.Headers["MyKey"] = "my value"; //custom stuff that shows in developer tools at network
    context.Response.Headers["Server"] = "My server"; //serf-explanatory
    context.Response.Headers["Content-Type"] = "text-html"; //type of content to be received
    await context.Response.WriteAsync("<h1>Hello<h1> ");
    await context.Response.WriteAsync("<h2>World<h2>");
});*/

/*
app.Run(async (HttpContext context) =>
{
    //string path = context.Request.Path;
    context.Response.Headers["Content-type"] = "text-html";
    if (context.Request.Method == "GET")
    {
        if(context.Request.Query.ContainsKey("id"))
        {
            string id = context.Request.Query["id"];
            await context.Response.WriteAsync(id);
        }
    }
   // await context.Response.WriteAsync($"<p>{path}<p>");
});*/

app.Run(async (HttpContext context) =>
{
  //  context.Response.Headers["Content-type"] = "text-html";

    /* if (context.Request.Query.ContainsKey("AuthorizationKey"))
     {
     // string userAgent = context.Request.Headers["User-Agent"];
         string authorizationKey = context.Request.Headers["AuthorizationKey"];
         await context.Response.WriteAsync($"<p>{authorizationKey}<p>");
     }
    */
    //scrii in postman host-ul exact (cu copy paste) ca sa mearga la debugging
    StreamReader reader = new StreamReader(context.Request.Body);
    string body =await  reader.ReadToEndAsync();
    Dictionary<string,StringValues> queryDict= Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(body);

    if(queryDict.ContainsKey("firstname"))
    {
        string firstName = queryDict["firstName"][0];
        await context.Response.WriteAsync(firstName);
    }
    
});
app.Run();
﻿using Microsoft.AspNetCore.Mvc;
using Razor_Views__MVC_.Models;

namespace Razor_Views__MVC_.Controllers
{
    public class HomeController : Controller
    {
        [Route("home")]
        [Route("/")] //default route
        public IActionResult Index()
        {
            ViewData["appTitle"] = "ASP.NET CORE App";
            Person person = new Person() { Name = "Joe", Birth = Convert.ToDateTime("2003-05-11") };
            List<Person> people = new() { person, new Person() { Name = "Hannah", Birth = Convert.ToDateTime("2005-09-27") } };
            ViewData["people"] = people; //ViewData is a dictionary[string] = object ; (it's allows kinda anything you need)
            return View(people);//Views//Home//Index.cshtml => looks for this folders
            //return View("abc"); => //abc.cshtml  (cs pt c# + html pt html) => default view (Razor View)
        }
        [Route("details/{name}")]
        public IActionResult Details(string? name)
        {
            Person person = new Person() { Name = "Joe", Birth = Convert.ToDateTime("2003-05-11") };
            List<Person> people = new() { person, new Person() { Name = "Hannah", Birth = Convert.ToDateTime("2005-09-27") } };
            Person personSeeked = people.Where(guy => guy.Name.Equals(name)).FirstOrDefault();
            return View("Details",personSeeked);  //Views/Home/Details.cshml  Views is the folder for views
          //Home is the folder for the Home controller views (each controller will have a views folder with same name, but without "Controller" as sufix)
          //inside Home are it's views
        }
        [Route("person-and-product/{name}")]
        public IActionResult Product()
        {
            Person person = new() { Name = "Joel", Birth=Convert.ToDateTime("2000-11-30") };
            Product product = new() { Id = new Guid(), Name = "Crappy laptop" };
            PersonAndProductWrapperModel modelWrapper= new() { person=person, product = product };
            return View("PersonAndProduct",modelWrapper); //you can't send more than one object to the view, but you can make a class that takes more classes inside of it (a wrapper)
        }
        [Route("All-products")]
        public IActionResult All() //condition for shared folder to work is to have the exact action method name as the view folder in "Shared"
        {
            return View();
        }
    }
}

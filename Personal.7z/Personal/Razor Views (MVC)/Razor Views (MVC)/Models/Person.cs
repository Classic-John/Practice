﻿namespace Razor_Views__MVC_.Models
{
    public class Person
    {
        public string? Name { get; set; }
        public DateTime? Birth { get; set; }
    }
    
}

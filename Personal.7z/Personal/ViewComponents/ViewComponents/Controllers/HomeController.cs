﻿using Microsoft.AspNetCore.Mvc;
using ViewComponents.Models;

namespace ViewComponents.Controllers
{
    public class HomeController : Controller
    {
        [Route("/")]
        public IActionResult Home()
        {
            PersonGridModel model = new PersonGridModel()
            {
                GridTitle = "People list",
                Persons = new List<Person>()
            {
                new Person("John","Manager"),
                new Person("Michael","Assistant manager"),
                new Person("William","Clerk")
            }
            };
            return View(model);
        }
        [Route("About")]
        public IActionResult About() 
        {
            return View();
        }
        [Route("load-stuff")]
        public IActionResult Load() 
        {
            PersonGridModel model = new PersonGridModel()
            {
                GridTitle = "Stuff list",
                Persons = new List<Person>()
            {
                new Person("Johnny","Boss Manager"),
                new Person("Michaela","medic"),
                new Person("Shakespear","genius")
            }
            };
            return ViewComponent("Grid",model); //specify the respective ViewComponent you want to invoke and , optionally, send it a parameter, making it strongly typed (recommended)
        }
    }
}

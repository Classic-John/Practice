﻿document.querySelector("#id-button").addEventListener("click", async function () { //REMEMBER: always put " # " before the id you want to use in querySelector
    var response = await fetch("load-stuff", { method: "GET" })  //write controller's route here
    var responseBody = await response.text(); 
    document.querySelector("#list").innerHTML=responseBody;  //returns the value to whatever element has identical id after the #
})
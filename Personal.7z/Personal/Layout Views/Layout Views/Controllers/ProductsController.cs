﻿using Microsoft.AspNetCore.Mvc;

namespace Layout_Views.Controllers
{
    public class ProductsController : Controller
    {
        [Route("product-info")]
        public IActionResult Info()
        {
            return View("Info");
        }
    }
}

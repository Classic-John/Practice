﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Eventing.Reader;
using Asp.net_tests.Models;
using Asp.net_tests.CustomModelBinders;

namespace Asp.net_tests.Controllers
{
    public class HomeController : Controller
    {
        [Route("register")]
        public IActionResult Index(Person person)//Bind(nameof(Person.Name))) 
        {
            if (!ModelState.IsValid)
            {
               // List<string> errors = new();
                //errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                string errors=string.Join("\n",ModelState.Values.SelectMany(value => value.Errors).Select(err=> err.ErrorMessage));

                /*
                foreach(var value in ModelState.Values) 
                {
                    foreach(var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                */
                //string allErrors = string.Join("\n", errors);
                return BadRequest(errors);
            }
            person.Name = "Test";
            person.Email = "Test1";
            person.Price = 1999;
            person.Phone = "1234567890";
            person.ConfirmPassword = "something";
            person.Password = "something";
            return Ok(person);
        }
        [Route("Testing")]
        public IActionResult Test([FromHeader(Name ="User-Agent")] string userAgent)  //how to extrat easily stuff from Header category
        {
            return Content(userAgent);
        }
        public IActionResult Test([FromBody][ModelBinder(BinderType =typeof(PersonModelBinder))] Person person) //rare usage for this
        {
            return Ok(person);
        }
    }
}
